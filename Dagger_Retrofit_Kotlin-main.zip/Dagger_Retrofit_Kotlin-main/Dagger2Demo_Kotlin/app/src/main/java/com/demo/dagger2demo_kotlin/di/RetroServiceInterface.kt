package com.demo.dagger2demo_kotlin.di

import com.demo.dagger2demo_kotlin.Modelclass.AstroMain

import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Query

interface RetroServiceInterface {



    @GET("feed")
    fun getDataFromAPI(@Query("start_date")Start_Date: String,
                                     @Query("end_date") End_Date: String,
                                     @Query("api_key")appId:String):Call<AstroMain>?
}