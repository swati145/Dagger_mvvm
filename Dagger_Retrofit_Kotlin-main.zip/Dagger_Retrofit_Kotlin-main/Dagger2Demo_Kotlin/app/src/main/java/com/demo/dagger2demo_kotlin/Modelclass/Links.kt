package com.demo.dagger2demo_kotlin.Modelclass

data class Links(
    val next: String,
    val prev: String,
    val self: String
)