package com.demo.dagger2demo_kotlin

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.MutableLiveData
import com.demo.dagger2demo_kotlin.Modelclass.AstroMain
import com.demo.dagger2demo_kotlin.di.RetroServiceInterface

import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import javax.inject.Inject

class MainActivityViewModel(application: Application) : AndroidViewModel(application){
    @Inject
    lateinit var mService: RetroServiceInterface

    private lateinit var liveDataList: MutableLiveData<AstroMain>


    init {
        //here we need to init application.
        (application as MyApplication).getRetroComponent().inject(this)
        liveDataList = MutableLiveData()
    }


    fun getLiveDataObserver(): MutableLiveData<AstroMain> {
        return liveDataList
    }

    fun makeApicall() {
        val call: Call<AstroMain>?  = mService.getDataFromAPI("2015-09-07","2015-09-08","DEMO_KEY")
        call?.enqueue(object : Callback<AstroMain>{
            override fun onFailure(call: Call<AstroMain>, t: Throwable) {
                liveDataList.postValue(null)
            }

            override fun onResponse(call: Call<AstroMain>, response: Response<AstroMain>) {
                if(response.isSuccessful) {
                    liveDataList.postValue(response.body())
                } else {
                    liveDataList.postValue(null)
                }
            }
        })
    }
}