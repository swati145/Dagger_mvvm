package com.demo.dagger2demo_kotlin

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.demo.dagger2demo_kotlin.Modelclass.CloseApproachData
import kotlinx.android.synthetic.main.recycler_view_list_row.view.*

class RecyclerViewAdapter: RecyclerView.Adapter<RecyclerViewAdapter.MyViewHolder>() {

    private var listData: List<CloseApproachData>? = null

    fun setUpdatedData(listData: List<CloseApproachData>) {
        this.listData = listData
    }

    class MyViewHolder(view: View): RecyclerView.ViewHolder(view) {

        val textviewDate = view.textviewdate
        val textviewfull = view.textview_full

        fun bind(data: CloseApproachData) {
            textviewDate.setText(data.close_approach_date)
            textviewfull.setText(data.close_approach_date_full)

        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.recycler_view_list_row, parent, false)
        return MyViewHolder(view)
    }

    override fun getItemCount(): Int {
        if(listData == null)return 0
        else return listData?.size!!
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        holder.bind(listData?.get(position)!!)
    }
}