package com.demo.dagger2demo_kotlin.Modelclass

data class LinksXX(
    val self: String
)