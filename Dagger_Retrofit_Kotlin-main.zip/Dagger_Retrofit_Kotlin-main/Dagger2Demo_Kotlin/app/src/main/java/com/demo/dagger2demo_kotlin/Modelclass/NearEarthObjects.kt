package com.demo.dagger2demo_kotlin.Modelclass

data class NearEarthObjects(
    val `a2015-09-07`: List<AstroMain>,
    val `2015-09-08`: List<X20150908>
)